package com.cg.enquiry.ui;

import java.io.IOException;
import java.sql.SQLException;
import java.util.*;

import com.cg.enquiry.dao.EnquiryDaoImpl;
import com.cg.enquiry.dto.EnquiryDetails;
import com.cg.enquiry.service.*;

public class EnquiryUI {
	
public static void main(String[] args) throws SQLException, IOException {
	Scanner sc = new Scanner(System.in);
	System.out.println("********Global recruitments********");
	System.out.println("Choose an operation ");
	while(true)
	{
	System.out.println("1.Enter Enquiry details\n2.View Enquiry details on id\n0.Exit");
	System.out.println("*******************");
	System.out.println("Please enter a choice");
	int choice = sc.nextInt();
	System.out.println("****************");
	switch(choice){
	case 1 : getAllEnquiry();
	break;
	case 2 : getDetailsById();
	break;
	case 0 : System.exit(0);
	}
	}
}

private static void getAllEnquiry() throws SQLException, IOException {
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter First name");
	String fname=sc.next();
	System.out.println("Enter last name");
	String lname=sc.next();
	System.out.println("Enter contact Number");
	long num=sc.nextLong();
	System.out.println("Enter domain name");
	String domain=sc.next();
	System.out.println("Enter Location");
	String loc=sc.next();
	EnquiryDetails ed =  new EnquiryDetails(fname,lname,num,domain,loc);
	IEnquiryService service = new EnquiryServiceImpl();
	int res = service.getAllEnquiry(ed);
	System.out.println(res+" updated");
	
	
}

private static void getDetailsById() throws SQLException, IOException {
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter id");
	int id = sc.nextInt();
	IEnquiryService service = new EnquiryServiceImpl();
	EnquiryDetails list = service.getEnquiryById(id);
	if(list.getfName()==null)
	{
		System.out.println("Details not found");
	}
	else {
	System.out.println("e_id\tfname\tlname\tnumber\tdomain\tloc");
		System.out.println(list);
	
}
}}
