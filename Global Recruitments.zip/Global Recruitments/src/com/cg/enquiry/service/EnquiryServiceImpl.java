package com.cg.enquiry.service;

import java.io.IOException;
import java.sql.SQLException;

import com.cg.enquiry.dao.EnquiryDaoImpl;
import com.cg.enquiry.dao.IEnquiryDao;
import com.cg.enquiry.dto.EnquiryDetails;

public class EnquiryServiceImpl implements IEnquiryService
{
	IEnquiryDao dao = new EnquiryDaoImpl();
	@Override
	public EnquiryDetails getEnquiryById(int e_id) throws SQLException, IOException {
		return dao.getEnquiryById(e_id);
	}

	public int getAllEnquiry(EnquiryDetails e) throws SQLException, IOException {
		// TODO Auto-generated method stub
	System.out.println("service hi");
		return dao.getAllEnquiry(e);
	}

}
