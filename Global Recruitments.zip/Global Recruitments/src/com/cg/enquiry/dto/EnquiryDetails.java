package com.cg.enquiry.dto;

public class EnquiryDetails {
@Override
	public String toString() {
		return fName+"\t" + lName+"\t" +
				 + phoneNum+"\t" +  Domain+"\t" +
				Location ;
	}
private String fName;
private String lName;
private long phoneNum;
private String Domain;
private String Location;

public EnquiryDetails(){
	
}


public EnquiryDetails(String fName, String lName, long phoneNum, String domain,
		String location) {
	super();
	this.fName = fName;
	this.lName = lName;
	this.phoneNum = phoneNum;
	Domain = domain;
	Location = location;
}


public String getDomain() {
	return Domain;
}

public void setDomain(String domain) {
	Domain = domain;
}

public String getfName() {
	return fName;
}
public void setfName(String fName) {
	this.fName = fName;
}
public String getlName() {
	return lName;
}
public void setlName(String lName) {
	this.lName = lName;
}
public long getPhoneNum() {
	return phoneNum;
}
public void setPhoneNum(long phoneNum) {
	this.phoneNum = phoneNum;
}
public String getLocation() {
	return Location;
}
public void setLocation(String location) {
	Location = location;
}
}
