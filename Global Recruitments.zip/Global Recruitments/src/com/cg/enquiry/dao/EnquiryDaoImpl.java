package com.cg.enquiry.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.enquiry.dto.EnquiryDetails;
import com.cg.enquiry.dbutil.DbUtil;

public class EnquiryDaoImpl implements IEnquiryDao{
	ArrayList<EnquiryDetails> a1 = new ArrayList<EnquiryDetails>();
	Connection conn = null;
	PreparedStatement  ps;
	@Override
	public EnquiryDetails getEnquiryById(int e_id) throws SQLException, IOException {
		conn = DbUtil.getConnection();
		System.out.println("dao hi");
		String str="select * from enquirydetails where e_id=?";
		ps=conn.prepareStatement(str);
		ps.setInt(1,e_id);
		ResultSet rs = ps.executeQuery();
		EnquiryDetails ed = new EnquiryDetails();
		while(rs.next()){
			ed = new EnquiryDetails();
			ed.setfName(rs.getString(2));
			ed.setlName(rs.getString(3));
			ed.setPhoneNum(rs.getLong(4));
			ed.setDomain(rs.getString(5));
			ed.setLocation(rs.getString(6));
		}
		return ed;
		
	}
	public int getAllEnquiry(EnquiryDetails e) throws SQLException, IOException {
		int rows=0;
		conn = DbUtil.getConnection();						  //sequence nme
		String insertQuery="insert into enquirydetails values(e_id_seq.nextval,?,?,?,?,?)";
		PreparedStatement ps=conn.prepareStatement(insertQuery);
		ps.setString(1,e.getfName());
		ps.setString(2,e.getlName());
		ps.setLong(3,e.getPhoneNum());
		ps.setString(4,e.getDomain());
		ps.setString(5,e.getLocation());
		rows = ps.executeUpdate();
		System.out.println("in dao"+rows);
		return rows;
	}
	
	}
