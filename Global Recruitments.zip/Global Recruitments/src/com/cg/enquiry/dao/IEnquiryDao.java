package com.cg.enquiry.dao;

import java.io.IOException;
import java.sql.SQLException;

import com.cg.enquiry.dto.EnquiryDetails;

public interface IEnquiryDao {
	public EnquiryDetails getEnquiryById(int e_id) throws SQLException, IOException;
	public int getAllEnquiry(EnquiryDetails e) throws SQLException, IOException;
}
