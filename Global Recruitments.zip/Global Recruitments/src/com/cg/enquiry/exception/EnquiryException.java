package com.cg.enquiry.exception;

public class EnquiryException {

}
